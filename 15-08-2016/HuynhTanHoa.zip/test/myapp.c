int main(){
	nhapNgaySinh();
}
